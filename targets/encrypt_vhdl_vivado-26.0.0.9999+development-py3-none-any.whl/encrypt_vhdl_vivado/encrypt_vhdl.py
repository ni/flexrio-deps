#!/usr/bin/env python3
import os
import shutil
import argparse
import ctypes
import sys
from ctypes import c_int32, c_char_p, c_size_t, POINTER, c_void_p, create_string_buffer
from pathlib import Path


def get_bundled_dll_paths():
    """Get paths to the DLLs bundled with this package."""
    package_dir = Path(__file__).parent
    encryption_dll = package_dir / "ieee1735Encrypt.dll"
    wrapper_dll = package_dir / "ni_encrypt_vhdl_vivado.dll"
    return str(encryption_dll), str(wrapper_dll)


class EncryptError(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(f"Encryption error: {code}")

class VhdlEncryption:
    def __init__(self, dll_path, encryption_dll_path):
        self.dll = ctypes.CDLL(dll_path)
        
        # Configure function signatures
        self.dll.Initialize.argtypes = [c_char_p]
        self.dll.Initialize.restype = c_int32
        
        self.dll.Cleanup.argtypes = []
        self.dll.Cleanup.restype = None
        
        self.dll.EncryptVHDL.argtypes = [
            c_char_p,    # input
            c_size_t,    # inputSize
            c_char_p,    # outBuf
            POINTER(c_size_t),  # outSize
            c_int32     # vivadoVersion
        ]
        self.dll.EncryptVHDL.restype = c_int32
        
        # Initialize the wrapper
        result = self.dll.Initialize(encryption_dll_path.encode('utf-8'))
        if result != 0:
            raise EncryptError(result)

    def __del__(self):
        if hasattr(self, 'dll'):
            self.dll.Cleanup()

    def encrypt(self, content, vivado_version=2024):
        """Encrypt VHDL content using the IEEE 1735 encryption"""
        try:
            # Convert content to bytes if it's not already
            if isinstance(content, str):
                content = content.encode('utf-8')
            
            # Prepare buffers
            input_size = len(content)
            output_size = c_size_t(input_size * 10)  # Allocate more space than needed
            output_buffer = create_string_buffer(output_size.value)
            
            # Call encryption function
            result = self.dll.EncryptVHDL(
                content,
                input_size,
                output_buffer,
                output_size,
                vivado_version
            )
            
            if result != 0:
                raise EncryptError(result)
            
            # Extract result
            encrypted_data = output_buffer[:output_size.value]
            return encrypted_data.decode('utf-8')
                
        except Exception as e:
            print(f"Error during encryption: {str(e)}")
            raise

def should_encrypt_file(filepath):
    """
    Determine if a file should be encrypted based on its name and extension.
    Returns True for .vhd files except PkgVersion.vhd
    """
    if not filepath.lower().endswith('.vhd'):
        return False
    return os.path.basename(filepath).lower() != 'pkgversion.vhd'

def process_directory(input_dir, output_dir, vivado_version):
    """
    Process all files in the input directory, creating an identical structure in the output directory
    but with encrypted VHDL files where appropriate.
    """
    encryption_dll_path, wrapper_dll_path = get_bundled_dll_paths()

    encrypted_count = 0
    copied_count = 0
    
    try:
        # Initialize encryption
        encryptor = VhdlEncryption(wrapper_dll_path, encryption_dll_path)
        
        # First, create all directories
        for root, dirs, _ in os.walk(input_dir):
            for dir_name in dirs:
                src_dir = os.path.join(root, dir_name)
                rel_path = os.path.relpath(src_dir, input_dir)
                dst_dir = os.path.join(output_dir, rel_path)
                os.makedirs(dst_dir, exist_ok=True)
        
        # Then process all files
        for root, _, files in os.walk(input_dir):
            for file in files:
                src_file = os.path.join(root, file)
                rel_path = os.path.relpath(src_file, input_dir)
                dst_file = os.path.join(output_dir, rel_path)
                
                if should_encrypt_file(src_file):
                    with open(src_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                        encrypted_content = encryptor.encrypt(content, vivado_version)
                    os.makedirs(os.path.dirname(dst_file), exist_ok=True)
                    with open(dst_file, 'w', encoding='utf-8') as f:
                        f.write(encrypted_content)
                    encrypted_count += 1
                else:
                    os.makedirs(os.path.dirname(dst_file), exist_ok=True)
                    shutil.copy2(src_file, dst_file)
                    copied_count += 1
    
    except Exception as e:
        print(f"Error in process_directory: {str(e)}")
        raise

    return encrypted_count, copied_count

def main():
    parser = argparse.ArgumentParser(description='Create encrypted copy of firmware directory')
    parser.add_argument('input_dir', help='Input directory containing firmware files')
    parser.add_argument('output_dir', help='Output directory for the encrypted copy')
    parser.add_argument('--vivado-version', type=int, default=2023,
                      help='Vivado major version to use for encryption (default: 2023)')
    
    args = parser.parse_args()
    
    encrypted_count, copied_count = process_directory(
        args.input_dir, 
        args.output_dir, 
        args.vivado_version,
    )
    
    print(f"Successfully processed {encrypted_count + copied_count} files:")
    print(f"  - {encrypted_count} files encrypted")
    print(f"  - {copied_count} files copied")

if __name__ == '__main__':
    main()
